﻿using CURDDemo;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Web.Mvc;

namespace CURDJqueryDemo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Save(EmployeeClass modal)
        {
            MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Insert(modal);
            return Json(mRes, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Update(EmployeeClass modal)
        {
            MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Update(modal);
            return Json(mRes, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(Int32 ID)
        {
            DataTable dt = new EmployeeLogic().Employee_Get(ID);

            string convertDataTableToJson = JsonConvert.SerializeObject(dt);

            return Json(convertDataTableToJson, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAll()
        {
            DataTable dt = new EmployeeLogic().Employee_GetAll();

            string convertDataTableToJson = JsonConvert.SerializeObject(dt);

            return Json(convertDataTableToJson, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Delete(Int32 ID)
        {
            MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Delete(ID);
            return Json(mRes, JsonRequestBehavior.AllowGet);
        }
    }
}